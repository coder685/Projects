import kaboom from "kaboom"

// initialize context
kaboom()
loadSprite("bean", "sprites/bean.png")




var diff = 0;



scene("start_menu", () => {

  const easys = add([
    text("Start"),
    pos(259, 200),
    scale(2),
    origin("center"),
    area({ cursor: "pointer", }),
    
  ])
  easys.onClick(() =>{
    go("diff_menu")
  })
  
  
})




scene("diff_menu", () => {
  const easy = add([
    text("easy"),
    pos(259, 200),
    scale(1),
    origin("center"),
    area({ cursor: "pointer", }),
    
  ])
  const medium = add([
    text("medium"),
    pos(259, 150),
    scale(1),
    origin("center"),
    area({ cursor: "pointer", }),
    
  ])
  const hard = add([
    text("hard"),
    pos(259, 100),
    scale(1),
    origin("center"),
    area({ cursor: "pointer", }),
    
  ])

  medium.onClick(() => {
    dif = 250;
    go("game")
  })
  hard.onClick(() => {
    dif = 500;
    go("game")
  })
  easy.onClick(() => {
    dif = 200;
    go("game")
  })
})


scene("pause", () => {

  add([
    text("paused"),
    pos(259, 100),
    scale(2),
    origin("center"),
  ]);

  


  onKeyPress("space", () => {
    go("game")
  })
  
})

scene("game", ()=>{
  var start = true;
  // load assets
  
  
  
  // add a character to screen
  var bean = add([
  	// list of components
  	sprite("bean"),
  	pos(50, 50),
  	area(),
    body(),
    "player"
  ])

  
  var score = 0

  
  

  add([
      rect(width(), 48),
      pos(0, height() - 48),
      outline(4),
      area(),
      solid(),
      color(127, 200, 255),
  ])
  
  
  var xy = loop(2, () => {
      // add tree
      add([
          rect(rand(15, 48), rand(15,48)),
          area(),
          outline(4),
          pos(width(), height() - 48),
          origin("botleft"),
          color(255, 180, 255),
          move(LEFT, dif),
          "tree", // add a tag here
      ]);
  });
  
  
  bean.onCollide("tree", () => {
    go("game")
    
    
  })


  onKeyPress("r", () => {
    go("pause")
  })

 
  onKeyPress("space", () => {
    if(bean.isGrounded()){
      bean.jump()
      score++;
      x.text = score;
        
    }
  })


 
  

  

  

  var x = add([
        text(score),
        pos(50, 50),
        scale(2),
        origin("center"),
  ]);
  
  // add a kaboom on mouse click
  onClick(() => {
  	addKaboom(mousePos())
  })
  
  // burp on "b"
  onKeyPress("b", burp)

  onClick(() => {
      if(bean.isGrounded()){
        bean.jump()
        score++;
        x.text = score;
      
      }
  })

})
go("start_menu")
