from django.db import models

# Create your models here.
class Product(models.Model):
 
  title = models.TextField(default="")
  info = models.TextField(default="")
  cert = models.BooleanField(default=False)
  likes = models.IntegerField(default=0)
  dislikes = models.IntegerField(default=0)
          




class Comment(models.Model):
  description = models.CharField(max_length=255)
  rating = models.IntegerField(default = 0)
  

