from django.contrib import admin
from .models import Product, Comment

class ProductAdmin(admin.ModelAdmin):
  list_display = ('title', 'info', 'cert')





admin.site.register(Product, ProductAdmin)



class CommentAdmin(admin.ModelAdmin):
  list_display= ('description', "rating")




admin.site.register(Comment, CommentAdmin)



