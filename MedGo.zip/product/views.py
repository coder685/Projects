from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from .models import Product, Comment 

first_time = True

# Create your views here.
def todoView(request):

  products = Product.objects.all()
  com = Comment.objects.all()

  h = "" 

  return render(request, "base.html", 
  {'items': products, 'h':com})



def add(request):
  

  return render(request, "pay.html")


def submit(request):

  

  

  data = Product(title=request.POST['title'], info=request.POST['info'])
  data.save()
  

  return render(request, "pay.html")


def like_add(request, li):

  da = Product.objects.get(title=li)
  da.likes += 1
  da.save()
  

  return HttpResponseRedirect('/')

def dislike_add(request, di):

  da = Product.objects.get(title=di)
  da.dislikes += 1
  da.save()
  

  return HttpResponseRedirect('/')


def content(request):
  com = Comment.objects.all()

  return render(request, "review.html", {"com": com, })


def contentd(request):
  x = request.POST['come']
  y = request.POST['num']

  c = Comment(description=x, rating=y)
  c.save()
  

  return render(request, "review.html")


