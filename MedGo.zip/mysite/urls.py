"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from product.views import todoView, submit, add, like_add, dislike_add, content, contentd

urlpatterns = [
    path('admin/', admin.site.urls),    
    path('', todoView),
    path('add/', add),
    path('added/', submit),
    path('<str:li>/sus/', like_add),
    path('<str:di>/suss/', dislike_add),
    path('reviews/', content),
    path('reviewed/', contentd)
    
    
  

]