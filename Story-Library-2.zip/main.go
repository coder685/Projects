package main

import (
	"fmt"
  "net/http"
  "html/template"
  "github.com/replit/database-go"
)





var xx = "hello world"

var story string
var title string
var name string


func main() {
	http.HandleFunc("/", SimpleServer)
  http.HandleFunc("/about", ComplexServer)
  http.HandleFunc("/sus", Yes)
  http.HandleFunc("/suss", ComplexServer1)
  http.ListenAndServe(":8080", nil)
  
}

type NewsAge struct {
  Key string
  Difi string
  One string
  Two string
}
func SimpleServer(w http.ResponseWriter, r *http.Request) {
  p := NewsAge{Key:"hello", Difi:"greeting somone", One:"hello"}
  t, _ := template.ParseFiles("index.html")

  fmt.Println(t.Execute(w, p))
  
}

func Yes(w http.ResponseWriter, r *http.Request) {
  p := NewsAge{Key:"hello", Difi:"greeting somone", One:xx}
  t, _ := template.ParseFiles("index.html")

  story = r.FormValue("story")
  title = r.FormValue("title")
  
  database.Set(title, story)

  fmt.Println(t.Execute(w, p))
  
}

func ComplexServer(w http.ResponseWriter, r *http.Request) {
  p := NewsAge{Key:"hello"}
  t, _ := template.ParseFiles("yes.html")

  
  

  fmt.Println(t.Execute(w, p))
  
}

func ComplexServer1(w http.ResponseWriter, r *http.Request) {
  name = r.FormValue("name")
  value, _ := database.Get(name)
  p := NewsAge{Key:value}
  t, _ := template.ParseFiles("yes.html")

  
  

  fmt.Println(t.Execute(w, p))
  
}
