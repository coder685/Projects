from django.db import models
from django.utils import timezone


# Create your models here.
class TodoItem(models.Model):
  content = models.TextField(default="hi");
  likes = models.IntegerField(default=0);
  dis_likes = models.IntegerField(default=0);

  def __str__(self):
    return self.content



class Comment(models.Model):
  post = models.ForeignKey(TodoItem, on_delete=models.CASCADE);
  text = models.TextField(default="hello");
  my_field = models.DateTimeField(default=timezone.now)
  

  def __str__(self):
    return self.post



