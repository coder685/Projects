from django.contrib import admin
from .models import TodoItem ,Comment

class Todo(admin.ModelAdmin):

  list_display = ("content", "likes", "dis_likes")



admin.site.register(TodoItem, Todo)


class Com(admin.ModelAdmin):

  list_display = ("post",)



admin.site.register(Comment, Com)