from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from .models import TodoItem


# Create your views here.
def todoView(request):

  all = TodoItem.objects.all()
  
  
  return render(request, 'index.html',    {'all': all})





def submit(request):
  
 return render(request, 'add.html', 
  {'all_items': ""})


def like(request, likes):


  xx = TodoItem.objects.get(content=likes)
  xx.likes += 1
  xx.save()

  return HttpResponseRedirect('/')

def dis(request, dislikes):


  xx = TodoItem.objects.get(content=dislikes)
  xx.dis_likes += 1
  xx.save()

  return HttpResponseRedirect('/')


def submited(request):

  x = request.POST['x']

  data = TodoItem(content=x)
  data.save()

  
  
  return render(request, 'add.html')




